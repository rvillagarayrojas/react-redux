import { useState, useEffect } from 'react'
import { useSelector, useDispatch } from 'react-redux'
import { FaUser } from 'react-icons/fa'
import { useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'
import { register, reset } from '../features/auth/authSlice'

const Register  = () => {
    const [formData, setFormData] = useState({
        name        : '',
        email       : '',
        password    : '',
        password2   : ''
    })

    const onChange = (e) =>{
        setFormData((prevState)=>({
            ...prevState,
            [e.target.name]:e.target.value
        }))
    }
    const onSubmit = (e) =>{
        e.preventDefault()
        if(password !== password2){
            toast.error('Los password no coindicen')
        }else{
            const userData = {
                name,
                email,
                password
            }
            dispatch(register(userData))            
        }

        
    }
    const {name, email, password, password2  } = formData

    const navigate = useNavigate()
    const dispatch = useDispatch()

    const { user, isLoadming, isError, isSuccess, message } = useSelector((state) => state.auth)

    return(
        <>
        <section className='heading'>
            <h1>
                <FaUser /> Registrar
            </h1>
            <p>Por favor crea un nuevo usuario</p>
        </section>
        <section className='form'>       
            <form onSubmit={onSubmit}>
                <div className="form-group">
                    <input type='text' id='name' name='name' className='form-control' value={name} placeholder='Ingresa tu nombre' onChange={onChange} />                        
                </div>        
                <div className="form-group">
                    <input type='email' id='email' name='email' className='form-control' value={email} placeholder='Ingresa tu email' onChange={onChange} />                        
                </div>        
                <div className="form-group">
                    <input type='password' id='password' name='password' className='form-control' value={password} placeholder='Ingresa tu password' onChange={onChange} />                        
                </div>        
                <div className="form-group">
                    <input type='password' id='password2' name='password2' className='form-control' value={password2} placeholder='Confirma tu nombre' onChange={onChange} />                        
                </div>                      
                <div className="form-group">
                    <button type='submit' className='btn btn-block'>Registrar</button>
                </div>                                                                                                          
            </form> 
            
        </section>        
        </>
    )
}


export default Register
