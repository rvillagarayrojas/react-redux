const Dashboard  = () => {
    return(
        <div>Basborad</div>
    )
}


export default Dashboard
