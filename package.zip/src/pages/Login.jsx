import { useState, useEffect } from 'react'
import { FaLock, FaUser } from 'react-icons/fa'

const Login  = () => {
    const [formData, setFormData] = useState({
        email       : '',
        password    : '',
    })

    const onChange = (e) =>{
        setFormData((prevState)=>({
            ...prevState,
            [e.target.name]:e.target.value
        }))
    }
    const onSubmit = (e) =>{
        e.preventDefault()
    }
    const { email, password } = formData
    return(
        <>
        <section className='heading'>
            <h1>
                <FaUser /> Login
            </h1>
            <p>Por favor ingrese sus credenciales</p>
        </section>
        <section className='form'>       
            <form onSubmit={onSubmit}>
                <div className="form-group">
                    <input type='email' id='email' name='email' className='form-control' value={email} placeholder='Ingresa tu email' onChange={onChange} />                        
                </div>        
                <div className="form-group">
                    <input type='password' id='password' name='password' className='form-control' value={password} placeholder='Ingresa tu password' onChange={onChange} />                        
                </div>        
                <div className="form-group">
                    <button type='submit' className='btn btn-block'><FaLock></FaLock> Iniciar Sesión</button>
                </div>                                                                                                          
            </form> 
            
        </section>        
        </>
    )
}


export default Login
